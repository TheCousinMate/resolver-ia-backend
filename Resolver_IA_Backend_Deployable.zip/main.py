
from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

app = FastAPI(
    title="Resolver IA API",
    description="API oficial de Resolver IA para decisiones estratégicas, lógica y análisis forense",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"status": "Resolver IA backend running"}

@app.post("/analyze")
def analyze(file: UploadFile = File(...)):
    content = file.file.read().decode("utf-8")
    lines = content.splitlines()
    return {
        "filename": file.filename,
        "lines": len(lines),
        "preview": lines[:5]
    }

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=7860, reload=True)
