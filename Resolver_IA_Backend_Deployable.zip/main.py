from fastapi import FastAPI, Request
import openai
import os

app = FastAPI()

openai.api_key = os.getenv("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")

@app.get("/")
def status():
    return {
        "status": "online",
        "engine": "Resolver IA v4.1",
        "author": "Kabir Hazbún"
    }

@app.get("/resolver")
async def resolver(q: str):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Eres un modelo experto en estrategia avanzada, lógica y análisis táctico"},
                {"role": "user", "content": q}
            ]
        )
        return {"respuesta": response["choices"][0]["message"]["content"]}
    except Exception as e:
        return {"error": str(e)}
